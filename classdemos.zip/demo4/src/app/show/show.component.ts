import { Component, OnInit } from '@angular/core';
import { Emp } from '../emp';

@Component({
  selector: 'app-show',
  templateUrl: './show.component.html',
  styleUrls: ['./show.component.css']
})
export class ShowComponent implements OnInit {
  emparr = new Array<Emp>();
  constructor() { 
    for (var i = 1; i<= 8;i++){
      var e = new Emp();
      e.empno = i;
      e.ename="Nameof"+i;
      e.salary = i*1000;
      if ( ( i %2)==0)
        e.city="Pnq";
      else 
        e.city = "Hyd";
        this.emparr.push(e);
    }
    console.log(this.emparr)
  }

  ngOnInit() {
  }

}
