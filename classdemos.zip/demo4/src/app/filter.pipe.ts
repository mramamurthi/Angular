import { Pipe, PipeTransform } from '@angular/core';
import { Emp } from './emp';

@Pipe({
  name: 'filter'
})
export class FilterPipe implements PipeTransform {

  transform(value: Array<Emp>, key:string, condi:any): Array<Emp>{
    var emparr = new Array<Emp>();
    console.log("key = "+ value[0][key] + ", condi " + condi)
    value.forEach(element => {
      if (element[key]== condi)
        emparr.push(element);
    });
    console.log("in filter transform")
    console.log(emparr);
    return emparr
  }

}
