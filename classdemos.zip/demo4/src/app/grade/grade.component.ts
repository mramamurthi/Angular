import { Component, OnInit, Input, 
  OnChanges,SimpleChanges, 
  EventEmitter, Output } from '@angular/core';

@Component({
  selector: 'app-grade',
  templateUrl: './grade.component.html',
  styleUrls: ['./grade.component.css']
})
export class GradeComponent implements OnInit, OnChanges {

  @Input()
  mrk=20;
  grade="Check";
  @Output()
  notify = new EventEmitter<String>();
  checkgrade(){
    if (this.mrk > 100)
    {
        console.log("in if >100")
        this.notify.emit("Invalid marks > 100");
    }
    if (this.mrk >=35)
      this.grade="PASS"
    else
      this.grade="FAIL"
  }
  constructor() {
    console.log("Mrk in constructor " + this.mrk)
   }

  ngOnInit() {
    console.log("Mrk in ngOnInit " + this.mrk)
    }
  ngOnChanges(changes: SimpleChanges): void {
    console.log("Mrk in ngOnChanges "+ this.mrk);
    console.log(changes);
    if (changes["mrk"])
      this.checkgrade();
  }
}
