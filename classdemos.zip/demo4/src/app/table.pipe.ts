import { Pipe, PipeTransform } from '@angular/core';
import { Emp } from './emp';

@Pipe({
  name: 'table'
})
export class TablePipe implements PipeTransform {
  constructor(){
    console.log("TablePipe Constructor ")
  }
  transform(value: Array<Emp>, ...args: any[]): string {
    var str ="";
    str += "<table border='1' bgcolor='cyan'>";
    str += "<th>EmpNo</th><th>Ename</th><th>Salary</th><th>City</th>";
    for (var i = 0;i < value.length;i++){
      str += "<tr><td>" + value[i].empno +"</td><td>"
      + value[i].ename +"</td><td>"
      + value[i].salary +"</td><td>"
      + value[i].city +"</td></tr>"
    }
    str+= "</table>";
    console.log(str)
    return str;
  }

}
