import { Component } from '@angular/core';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  name = 'Studentname';
  marks = 0;

 handle( reason:String){
   console.log("In app component handle " + reason)
 }

}
