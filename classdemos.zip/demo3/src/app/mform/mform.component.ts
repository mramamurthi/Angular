import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { Emp } from '../emp';

@Component({
  selector: 'app-mform',
  templateUrl: './mform.component.html',
  styleUrls: ['./mform.component.css']
})
export class MformComponent implements OnInit {
  emp:Emp = null;
  formgroup:FormGroup
  fcnames:Array<String>;
  constructor( formbuilder:FormBuilder)
   {  
     this.formgroup = formbuilder.group({
       "empnofc":[""],
       "enamefc":["",[Validators.required, Validators.minLength(4),Validators.maxLength(10)]],
       "salaryfc":["",[Validators.min(1000), Validators.max(2000)]]
     });
     console.log(this.formgroup);
     this.fcnames = Object.keys(this.formgroup.controls);
     console.log(this.fcnames)
   }

  ngOnInit() {
  }

  public submit(){
    console.log("in submit");
    console.log(this.formgroup);
    this.emp = new Emp();
    this.emp.empno = this.formgroup.value["empnofc"];
    this.emp.ename = this.formgroup.value["enamefc"];
    this.emp.salary = this.formgroup.value["salaryfc"];
    console.log(this.emp);
  }
}
