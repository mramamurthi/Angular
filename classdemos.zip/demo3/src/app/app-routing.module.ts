import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { TformComponent } from './tform/tform.component';
import { MformComponent } from './mform/mform.component';

const routes: Routes = [
  {path:'tform',component:TformComponent},
  {path:'mform',component:MformComponent}
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
