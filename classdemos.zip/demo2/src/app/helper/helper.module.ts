import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { App4Component } from './app4/app4.component';
import { App5Component } from './app5/app5.component';
import { Routes, RouterModule } from '@angular/router';

const childroutes: Routes = [
  {path:"app4url",component:App4Component},
  {path:"app5url",component:App5Component}
];

@NgModule({
  declarations: [App4Component, App5Component],
  imports: [
    CommonModule, RouterModule.forChild(childroutes)
  ]
})
export class HelperModule { }
