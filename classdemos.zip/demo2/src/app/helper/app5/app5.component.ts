import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-app5',
  templateUrl: './app5.component.html',
  styleUrls: ['./app5.component.css']
})
export class App5Component implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
