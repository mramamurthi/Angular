import { Component, OnInit } from '@angular/core';
import { MyService } from '../my.service';
import { convertPropertyBindingBuiltins } from '@angular/compiler/src/compiler_util/expression_converter';
import { ActivatedRoute } from '@angular/router';

@Component({
  selector: 'app-display',
  templateUrl: './display.component.html',
  styleUrls: ['./display.component.css'],
   
})
export class DisplayComponent implements OnInit {
  page:number=1
  arr = []

  constructor(private myserv:MyService, 
      private route:ActivatedRoute) {
    console.log(myserv)
    console.log(route.snapshot.params['pg'])
   }

  ngOnInit() {
  }
 public invoke(){
   //this.route.
    tmp = this.myserv.getdata("https://reqres.in/api/users?page="
        +this.route.snapshot.params['pg'])
        .subscribe(
      (respobj)=>{this.arr =respobj["data"];console.log(this.arr);  },
      (err)=>{console.log("error");}
    );
  }
}
