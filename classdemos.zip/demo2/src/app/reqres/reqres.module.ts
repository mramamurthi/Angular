import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import {HttpClientModule} from '@angular/common/http';
import { Routes, RouterModule } from '@angular/router';
import { FormsModule } from '@angular/forms';
import { MyService } from './my.service';
import { DisplayComponent } from './display/display.component';

const routes: Routes = [
  {path:"getdata/:pg",component:DisplayComponent},
];



@NgModule({
  declarations: [DisplayComponent],
  imports: [
    CommonModule,HttpClientModule,
      RouterModule.forChild(routes),
      FormsModule

  ],
  providers:[MyService]
})
export class ReqresModule { }
