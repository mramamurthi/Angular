import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { App2Component } from './app2/app2.component';
import { App3Component } from './app3/app3.component';

const routes: Routes = [
  {path:"app2url",component:App2Component, canActivate:[false]},
  {path:"app3url",component:App3Component},
  {path:"helper", loadChildren:  () => import('./helper/helper.module').then(mod => mod.HelperModule) },
  {path:"reqres", loadChildren:'./reqres/reqres.module#ReqresModule'}
];

@NgModule({
  imports: [RouterModule.forRoot(routes,{useHash:true})],
  exports: [RouterModule]
})
export class AppRoutingModule { }
