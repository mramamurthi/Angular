import { Component } from '@angular/core';
import {DemolibService}  from 'vaishalitapaswi';
@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  constructor(private dls:DemolibService){  }
  counter = 0
  title = 'demo6libclient';
  check(){
    this.dls.increment();
    this.counter = this.dls.getcount()  
  }
}
