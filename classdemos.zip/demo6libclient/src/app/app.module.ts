import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import {DemolibComponent} from 'vaishalitapaswi'
import { AppComponent } from './app.component';

@NgModule({
  declarations: [
    AppComponent,DemolibComponent
  ],
  imports: [
    BrowserModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
