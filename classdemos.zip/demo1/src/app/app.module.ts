import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';

import { AppComponent } from './app.component';

import { App1Component } from './app1/app1.component';
import { HelperModule } from './helper/helper.module';

@NgModule({
  declarations: [
    AppComponent,
    App1Component
  ],
  imports: [
    HelperModule, BrowserModule
  ],
  providers: [],
  bootstrap: [AppComponent,App1Component]
})
export class AppModule { }
