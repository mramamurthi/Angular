import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { App2Component } from './app2/app2.component';
import { App3Component } from './app3/app3.component';

@NgModule({
  declarations: [App2Component, App3Component],
  imports: [
    CommonModule
  ],
  exports : [App2Component]
  
})
export class HelperModule { }
