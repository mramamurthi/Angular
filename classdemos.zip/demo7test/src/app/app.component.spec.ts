import { TestBed, async } from '@angular/core/testing';
import { AppComponent } from './app.component';
import { FormsModule } from '@angular/forms';
import { By } from '@angular/platform-browser';
import { compilePipeFromRender2 } from '@angular/compiler/src/render3/r3_pipe_compiler';

describe('AppComponent', () => {
  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [
        AppComponent
      ],
      imports: [FormsModule]
    }).compileComponents();
  }));
  it('should create the app', () => {
    const fixture = TestBed.createComponent(AppComponent);
    const app = fixture.debugElement.componentInstance;
    expect(app).toBeTruthy();
  });

  it(`should have as title 'demo7test'`, () => {
    const fixture = TestBed.createComponent(AppComponent);
    const app = fixture.debugElement.componentInstance;
    expect(app.title).toEqual('demo7test');
  });

  it('should render title in a h1 tag', () => {
    const fixture = TestBed.createComponent(AppComponent);
    fixture.detectChanges();
    const compiled = fixture.debugElement.nativeElement;
    expect(compiled.querySelector('h1').textContent).toContain('Welcome to demo7test!');
  });
  
  it('counter initializion in h2 tag', () => {
    const fixture = TestBed.createComponent(AppComponent);
    fixture.detectChanges();
    const compiled = fixture.debugElement.nativeElement;
    const button:HTMLInputElement  = compiled.querySelector('input')
    var count = compiled.querySelector('h2').textContent;
    button.dispatchEvent(new Event("click"));
    fixture.detectChanges();
    expect(compiled.querySelector('h2').textContent).toContain('1');
  });
  
  it('should render title in a h1 tag', () => {
    const fixture = TestBed.createComponent(AppComponent);
    fixture.detectChanges();
    const compiled = fixture.debugElement.nativeElement;
    expect(compiled.querySelector('h1').textContent).toContain('Welcome to demo7test!');
  });
it('add working as controller', () => {
    const fixture = TestBed.createComponent(AppComponent);
    const compiled = fixture.debugElement.nativeElement;
    var comp1 = fixture.componentInstance
    comp1.no1 = 100;
    comp1.no2 = 300;
    comp1.add();
    expect(comp1.sum).toEqual(400);
  });
  it('add working as view',async(() => {
    const fixture = TestBed.createComponent(AppComponent);
    fixture.detectChanges();
	  fixture.whenStable().then(() => {
      const compiled = fixture.debugElement.nativeElement;
      let inputno1:HTMLInputElement  = compiled.querySelector("input[name='num1nm']");
      let inputno2:HTMLInputElement  = compiled.querySelector("input[name='num2nm']");
      
      inputno1.value = "101";
      inputno2.value = "202";
      
      inputno1.dispatchEvent(new Event("input"))
      inputno2.dispatchEvent(new Event("input"))
      
      let button:HTMLInputElement  = compiled.querySelector("input[name='ad']")
      button.dispatchEvent(new Event("click"));
      fixture.detectChanges();
      expect(compiled.querySelector("h3").textContent).toContain('303');
  })
}))
});
