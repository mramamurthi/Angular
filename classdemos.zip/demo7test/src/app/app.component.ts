import { Component } from '@angular/core';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  title = 'demo7test';
  counter = 0;
  no1 = 22;
  no2 = 11;
 
  sum=0
  inc(){
    this.counter++;
  }
  
  add(){
    console.log("in add no1 = " + this.no1 + ", no2= "+ this.no2);
    this.sum = this.no1+ this.no2
  }
}
