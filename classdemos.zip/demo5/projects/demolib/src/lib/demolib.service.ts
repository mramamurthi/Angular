import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class DemolibService {
  private count=0
  constructor() {
    console.log("in DemolibService contructor")
   }
   public increment(){
     console.log("increment invoked ...");
     this.count++;
   }
   public getcount():number{
     console.log("getcount invoked ..")
     return this.count;
   }
}
