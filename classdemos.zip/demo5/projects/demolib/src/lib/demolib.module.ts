import { NgModule } from '@angular/core';
import { DemolibComponent } from './demolib.component';
import { DemolibService } from './demolib.service';

@NgModule({
  declarations: [DemolibComponent],
  imports: [
  ],
  
  exports: [DemolibComponent]
})
export class DemolibModule { }
