import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'lib-demolib',
  template: `
    <p>
      demolib works!
    </p>
  `,
  styles: []
})
export class DemolibComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
